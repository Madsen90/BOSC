#ifndef _SLEEP_H
#define _SLEEP_H

void Sleep(float t);

#endif
