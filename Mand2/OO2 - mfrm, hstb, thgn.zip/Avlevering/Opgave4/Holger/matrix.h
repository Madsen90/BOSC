#ifndef _MATRIX_H
#define _MATRIX_H

void allocate_matrix_int(int*** mat, int m, int n);
void free_matrix_int(int*** mat, int m);

#endif
