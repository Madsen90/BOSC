/*
Do not modify this file.
Make all of your changes to main.c instead.
*/

#ifndef PROGRAM_H
#define PROGRAM_H

void scan_program( char *data, int length );
void sort_program( char *data, int length );
void focus_program( char *data, int length );
void test_program( char *data, int length );

#endif
