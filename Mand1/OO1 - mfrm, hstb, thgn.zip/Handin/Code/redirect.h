/* 
   Opgave 2

   redirect.h

 */

#ifndef _REDIRECT_H
#define _REDIRECT_H

int redirect_stdincmd(int);
int redirect_stdoutcmd(int);
#endif
