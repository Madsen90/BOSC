/* 

   Opgave 1

   forback.h

 */

#ifndef _FORBACK_H
#define _FORBACK_H
int foregroundcmd(char*, char**, int, int, int);
int backgroundcmd(char*, char**, int, int, int);

#endif
